#Rtsp2Rtmp
An Java application that use multithreading that pull the rtsp streams from Rtsp server and convert the stream into rtmp format and push to the Rtmp Server.
