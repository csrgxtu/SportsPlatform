[Getting started with nginx rtmp](https://github.com/arut/nginx-rtmp-module/wiki/Getting-started-with-nginx-rtmp)

[How to install tomcat 8 on ubuntu 14.04](http://www.itzgeek.com/how-tos/linux/ubuntu-how-tos/how-to-install-tomcat-8-on-ubuntu-14-04.html#axzz3X9ZOxDW5)

[HOW TO: Get Dynamic Web Project option in Eclipse](http://coding-for-dummies.blogspot.sg/2012/10/how-to-get-dynamic-web-project-option.html)

[JAVA SSH 框架介绍](http://anyun.org/a/jishuguanzhu/bianchengchalou/JAVA/2015/0218/4954.html)

[关于Java的SSH三大框架的学习建议](http://segmentfault.com/q/1010000000095243)

[什么是JSP？](http://anyun.org/a/jishuguanzhu/bianchengchalou/JAVA/2015/0218/4955.html)

[Eclipse shortcut keys](http://www.shortcutworld.com/en/win/Eclipse.html)

[coding for dummies](http://coding-for-dummies.blogspot.sg/?view=classic)

[Apache Tomcat Eclipse Integration](https://www.mulesoft.com/tcat/tomcat-eclipse)

[JWplayer embed guide](http://coolestguidesontheplanet.com/videodrome/jwplayer/)

[Java Server-side Programming Getting started with JSP by Examples](https://www3.ntu.edu.sg/home/ehchua/programming/java/JSPByExample.html)
